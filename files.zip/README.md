# Advanced Todo List Application

A minimal, professional todo list app with dark mode, Pomodoro timer, drag-and-drop, calendar view, and nested subtasks.

## Project Structure

```
ai-todo-list/
├── index.html              # Main HTML structure only
├── css/
│   └── style.css           # All styling (responsive, light/dark theme)
├── js/
│   └── app.js              # All JavaScript logic
├── api/
│   ├── getTodos.php        # Fetch todos from database
│   ├── addTodo.php         # Add todo to database
│   ├── deleteTodo.php      # Delete todo from database
│   └── updateTodo.php      # Update todo in database
├── db/
│   └── config.php          # Database connection config
└── README.md               # This file
```

## Setup Instructions

### 1. Create Database

1. Open **phpMyAdmin**: `http://localhost/phpmyadmin`
2. Create database: `ai_todo_list`
3. Run this SQL:

```sql
CREATE TABLE todos (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  completed BOOLEAN DEFAULT FALSE,
  priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
  dueDate DATE,
  status ENUM('backlog', 'inprogress', 'done') DEFAULT 'backlog',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### 2. File Structure in XAMPP

Place all files in: `C:\xampp\htdocs\ai-todo-list\`

```
C:\xampp\htdocs\ai-todo-list\
├── index.html
├── css/style.css
├── js/app.js
├── api/
│   ├── config.php
│   ├── getTodos.php
│   ├── addTodo.php
│   └── deleteTodo.php
├── db/
│   └── config.php
└── README.md
```

### 3. Access the App

1. Start XAMPP (Apache + MySQL)
2. Visit: `http://localhost/ai-todo-list`

## Features

✅ **Dark/Light Mode** - Toggle in header  
✅ **Drag & Drop** - Reorder tasks  
✅ **Pomodoro Timer** - 25min work + 5min break  
✅ **Calendar View** - Tasks by date  
✅ **Kanban Board** - Backlog, In Progress, Done  
✅ **Nested Subtasks** - Break down tasks  
✅ **Priority Levels** - High, Medium, Low  
✅ **Statistics** - Total, completed, pending, overdue  

## Design Inspiration

Inspired by [Dominik Koch](https://dominikkoch.dev) — minimal, professional aesthetic with:
- Balanced gray color palette
- Smooth animations
- Clean typography
- Subtle shadows & borders

## Current Storage

**Currently:** localStorage (browser storage - no database needed)  
**Later:** Will connect to PHP/MySQL for server-side persistence

## Color Palette

**Light Theme:**
- Background: #fafafa
- Secondary: #f0f0f0
- Text: #222222
- Accent: #0ea5e9

**Dark Theme:**
- Background: #1a1a1a
- Secondary: #242424
- Text: #e8e8e8
- Accent: #38bdf8

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Future Features

- [ ] Connect to PHP/MySQL backend
- [ ] User authentication
- [ ] Shared tasks/teams
- [ ] Claude AI integration (smart task breakdown, prioritization)
- [ ] Email reminders
- [ ] Mobile app
- [ ] Export to CSV/PDF

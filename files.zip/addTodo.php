<?php
require '../db/config.php';

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['text']) || empty($data['text'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Todo text is required']);
    exit;
}

$text = $data['text'];
$priority = $data['priority'] ?? 'medium';
$dueDate = $data['dueDate'] ?? NULL;
$status = $data['status'] ?? 'backlog';

// Insert todo
$stmt = $conn->prepare("
    INSERT INTO todos (title, priority, dueDate, status) 
    VALUES (?, ?, ?, ?)
");

if (!$stmt) {
    http_response_code(500);
    echo json_encode(['error' => $conn->error]);
    exit;
}

$stmt->bind_param('ssss', $text, $priority, $dueDate, $status);

if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'id' => $conn->insert_id,
        'text' => $text,
        'priority' => $priority,
        'dueDate' => $dueDate,
        'status' => $status
    ]);
} else {
    http_response_code(500);
    echo json_encode(['error' => $stmt->error]);
}

$stmt->close();
?>
